-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1849000
-- Name: SEX with HITLER
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: SEX with HITLER
-- App ID: 1849000

addappid(1849000)  -- SEX with HITLER

addappid(1849001, 1, "60f69dc6c86553a46cee8272fd7794764e8f6008077cc94056f5c4ea0498dd85")  -- Depot 1849001
setManifestid(1849001, "7808829540214624883")

setManifestid(1872950, "1516284714333816846")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 13:39:16 GMT
-- Depots: 1 | Manifests: 2 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


