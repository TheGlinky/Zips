-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 10090
-- Name: Call of Duty: World at War
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Call of Duty: World at War
-- App ID: 10090

addappid(10090)  -- Call of Duty: World at War

addappid(10091, 1, "10ec612dbb207b40a95f3d87dfa3ff720d38ae05a9cacedba92b2c584451bf9b")  -- Depot 10091
setManifestid(10091, "5566849738478017518")

addappid(10092, 1, "73dd3d3391cf0a30abe562035102c9d47b5d8b8ac6f48d8e574b5501926a5bbc")  -- Depot 10092
setManifestid(10092, "3607600095703252129")

addappid(10093, 1, "2c33b9a6afc043bce38f9c0ba564194895df35c12a885b7bf4cfc6c2e1a18bd2")  -- Depot 10093
setManifestid(10093, "6144874664931741841")

addappid(10094, 1, "7983e119dfd3586cc64677816aa111a598ba49e1d7e92c6b4db8cc9242ecdb86")  -- Depot 10094
setManifestid(10094, "8930507410861259500")

addappid(10095, 1, "fe273171200d3e2271a7dddc4064869e3e4966799e710e805be043c2c30ad554")  -- Depot 10095
setManifestid(10095, "1277981520695176614")

addappid(10096, 1, "e2dbc935ca2ae935ac53479fd77846231acb660baf06b3535d76abc4ccf61c81")  -- Depot 10096
setManifestid(10096, "6181330962488495469")

addappid(10097, 1, "e416f35d0a6911df372411ff0e1dd8ecfec26424c41e0dfe24c4f5db9e1804d1")  -- Depot 10097
setManifestid(10097, "2802736360734339490")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:25:53 GMT
-- Depots: 7 | Manifests: 7 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


