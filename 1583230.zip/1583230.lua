-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1583230
-- Name: High On Life
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: High On Life
-- App ID: 1583230

addappid(2447000)  -- High On Life: High On Knife (DLC)

addappid(1583230)  -- High On Life
addappid(228989,0,"ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")  -- Depot 228989
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
addappid(1583231,0,"a1246164a71713be03e1d57a313af03ac5bbde4a6a16962178bce5f74be271e4")  -- Depot 1583231
setManifestid(228989,"3514306556860204959")
setManifestid(228990,"1829726630299308803")
setManifestid(1583231,"4739388032191335402")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:20:23 GMT
-- Depots: 3 | Manifests: 3 | All included ✓
-- DLCs: 1
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


