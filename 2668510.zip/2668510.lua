-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 2668510
-- Name: Red Dead Redemption
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Red Dead Redemption
-- App ID: 2668510

addappid(2668510)  -- Red Dead Redemption

addappid(2668511, 1, "839eae6ac7edb75331c27732d207b339d78db2f2bd634989b08bd602a4c5983b")  -- Depot 2668511
setManifestid(2668511, "870294950404908569")

addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")  -- Depot 228989
setManifestid(228989, "3514306556860204959")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")  -- Depot 1899671
setManifestid(1899671, "274155245002712969")

addappid(2668512, 1, "ba1f0d8d7f0e02e8659bdd8d6a7738133974941d2da9845ae59a4f0fa456d801")  -- Depot 2668512
setManifestid(2668512, "4863697874015475084")

addappid(2668513, 1, "af2b732e108f2a10ed375b7042e3aa1cbdf57dc59dc07c303a7d9d31e81b9c59")  -- Depot 2668513
setManifestid(2668513, "14321031912871209")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:27:22 GMT
-- Depots: 6 | Manifests: 6 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


