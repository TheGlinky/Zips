-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 2562240
-- Name: Only Up!
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Only Up!
-- App ID: 2562240

addappid(2562240)  -- Only Up!

addappid(2562241, 1, "9e5f9c074ee6c5b6c0e09cf2c822245a1308e9bb08b13a819af611aefa55e108")  -- Depot 2562241
setManifestid(2562241, "177038400603460801")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 15:00:47 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


