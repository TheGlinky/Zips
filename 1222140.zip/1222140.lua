-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1222140
-- Name: Detroit: Become Human
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Detroit: Become Human
-- App ID: 1222140

addappid(1222140)  -- Detroit: Become Human

addappid(1222141, 1, "d87af32872df297ec519d0e79b6e0afc327b09048c3414622606b54efc46f519")  -- Depot 1222141
setManifestid(1222141, "7324084008489949045")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 13:29:30 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


