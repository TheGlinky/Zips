-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 284160
-- Name: BeamNG.drive
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: BeamNG.drive
-- App ID: 284160

addappid(284160)  -- BeamNG.drive

addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229")  -- Depot 284161
setManifestid(284161, "8515658310780597919")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:05:58 GMT
-- Depots: 2 | Manifests: 2 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


