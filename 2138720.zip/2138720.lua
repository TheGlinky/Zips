-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 2138720
-- Name: REMATCH
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: App 2138720
-- App ID: 2138720

addappid(2138720)  -- App 2138720

addappid(2138721, 1, "c1a2b9eea7346395b175b2d8458f566dcabe83b99822111d3446a5ce377bdc52")  -- Depot 2138721
setManifestid(2138721, "5785531273047925282")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 15:09:57 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


