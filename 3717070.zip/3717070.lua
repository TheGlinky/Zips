-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: WWE 2K26
-- App ID: 3717070

addappid(4181610)  -- WWE 2K26 Ringside Pass Premium Season 2 (DLC)
addappid(4181540)  -- WWE 2K26 Joe Hendry Pack (DLC)

addappid(3717070)  -- WWE 2K26
addappid(4429680)  -- WWE 2K26 Monday Night War Edition (DLC)
addappid(4357050)  -- WWE 2K26 Superstar Mega-Boost (DLC)
addappid(4333560)  -- WWE 2K26 Season Pass (DLC)
addappid(4181590)  -- WWE 2K26 Ringside Pass Premium Season 1 (DLC)
addappid(4181570)  -- WWE 2K26: Monday Night War Edition Pack (DLC)
addappid(4181560)  -- WWE 2K26: Attitude Era Edition Pack (DLC)
addappid(4181550)  -- WWE 2K26: King of Kings Edition Pack (DLC)
addappid(4125680)  -- WWE 2K26: MyRISE Boost (DLC)
addappid(3717071,0,"1bf7a881a3e1aceec7d3d40622e631e3d7472b7fb4a051051a5e151bb63d7c21")  -- Depot 3717071
setManifestid(3717071, "4010097485124193542")
-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 05:07:08 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 10
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════
