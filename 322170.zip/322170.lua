-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 322170
-- Name: Geometry Dash
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Geometry Dash
-- App ID: 322170

addappid(322170)  -- Geometry Dash

addappid(322171, 1, "73d09cfe5a697e2e5bf2a2591259e00c715e9dc3376d4a71ff7e915483be399d")  -- Depot 322171
setManifestid(322171, "3816559102876907245")

addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")  -- Depot 228989
setManifestid(228989, "3514306556860204959")

addappid(322172, 1, "6accd00ac7da1a455e3e689eed217adcdcb14198e5dd23b1e553abbed6d5c38e")  -- Depot 322172
setManifestid(322172, "8780295549609362522")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 13:53:28 GMT
-- Depots: 3 | Manifests: 3 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


