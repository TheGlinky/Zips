-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1174180
-- Name: Red Dead Redemption 2
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Red Dead Redemption 2
-- App ID: 1174180

addappid(1174180)  -- Red Dead Redemption 2
addappid(228987)  -- App 228987
addappid(1174180)  -- Red Dead Redemption 2

addappid(1174181, 1, "6fbf0f4b33fd5111d0832f0fb63a4d185c5321901ef95776c73e6e10b203bc25")  -- Depot 1174181
setManifestid(1174181, "4757128409362785099")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

addappid(1174182, 1, "0824e4e00b9d464a1352b0eaa60416ee3bfe0f3b416459991dc6fca87e84366f")  -- Depot 1174182
setManifestid(1174182, "2258488483491377476")

addappid(1174183, 1, "cd51ee7e8adde797736bc283f9d434fae0aac28753e3f38a29a78aac298c0ccf")  -- Depot 1174183
setManifestid(1174183, "4785346550216140531")

addappid(1174184, 1, "506c8f971b77f5c39f8baa54fac090e79bf32e19d92eca2a34cba9569bbe5d8a")  -- Depot 1174184
setManifestid(1174184, "2698939236196220127")

addappid(1174185, 1, "6fe9c5b4e41f1f91b6a775dd562515e9652570cc607caedef2bc4a9d522fea4d")  -- Depot 1174185
setManifestid(1174185, "8173342615013177810")

addappid(1174186, 1, "0ef7331ad866994474a72131eeb1a5667dc8c9f7be87b4e1d805f288e1d49432")  -- Depot 1174186
setManifestid(1174186, "357926288062992323")

addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")  -- Depot 1899671
setManifestid(1899671, "274155245002712969")

addappid(1174180, 1, "c4ba69ff66208b16fc27679ceefb89d490776fc18bae801311a31b6855b74783")  -- Depot 1174180 (Shared)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e")  -- Depot 228987

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:18:25 GMT
-- Depots: 10 | Manifests: 8 | Missing: 2
-- DLCs: 1
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


