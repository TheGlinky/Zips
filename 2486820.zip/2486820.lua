-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 2486820
-- Name: Sonic Racing: CrossWorlds
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Sonic Racing: CrossWorlds
-- App ID: 2486820

addappid(3601480)  -- Sonic Racing: CrossWorlds - Mega Man Pack (DLC)
addappid(3601440)  -- Sonic Racing: CrossWorlds - PAC-MAN Pack (DLC)
addappid(3601430)  -- Sonic Racing: CrossWorlds - SpongeBob SquarePants Pack (DLC)
addappid(3565190)  -- Sonic Racing: CrossWorlds - Minecraft Pack (DLC)
addappid(3592250)  -- Sonic Racing: CrossWorlds Season Pass (DLC)
addappid(3601510)  -- Sonic Racing: CrossWorlds - "Blue Star" Extreme Gear (DLC)

addappid(2486820)  -- Sonic Racing: CrossWorlds

addappid(2486821, 1, "08e2539b55bc79fefa9447d3479c57b481c4256c12ebd50529fc3722fcc3727f")  -- Depot 2486821
setManifestid(2486821, "3494414753270212375")

addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")  -- Depot 228989
setManifestid(228989, "3514306556860204959")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 13:53:03 GMT
-- Depots: 3 | Manifests: 3 | All included ✓
-- DLCs: 6
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


