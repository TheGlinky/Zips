-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 2729480
-- Name: NightClub Simulator
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: App 2729480
-- App ID: 2729480

addappid(2729480)  -- App 2729480

addappid(2729481, 1, "a888843dc7baaa68b8424ca0216fce2c36531da9f8266b9dbd656f37cf619746")  -- Depot 2729481
setManifestid(2729481, "8719821544208202831")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 15:02:29 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


