-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 3065800
-- Name: Marathon
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Marathon
-- App ID: 3065800

addappid(3065800)  -- Marathon
addappid(3065803)  -- App 3065803
addappid(3065804)  -- App 3065804
addappid(3065805)  -- App 3065805
addappid(3065806)  -- App 3065806
addappid(3065807)  -- App 3065807
addappid(3065808)  -- App 3065808
addappid(3065809)  -- App 3065809
addappid(3551860)  -- App 3551860
addappid(3551861)  -- App 3551861
addappid(3551862)  -- App 3551862
addappid(3551863)  -- App 3551863
addappid(3551864)  -- App 3551864
addappid(3569730)  -- App 3569730
addappid(3569750)  -- Marathon Deluxe Edition (DLC)
addappid(3569830)  -- Marathon Deluxe Upgrade (DLC)
addappid(4055980)  -- App 4055980
addappid(3065801,0,"0e21278144bf376c7d8a34cb2a28b38a275c0948bd8fc261dd86cba20a0b8ea3")  -- Depot 3065801
setManifestid(3065801, "5824324816702037678")
addappid(3065802,0,"38a83f9c6804a02c2d936cf077be40121279da28d9e149a70a1e8ca56f42b259")  -- Depot 3065802
setManifestid(3065802, "6442289980321782345")

addappid(3065803, 1, "2496fa9f81f8aacaacfac61694400da95175f86b031427303fd5b0cff59775cb")  -- Depot 3065803
setManifestid(3065803, "7600558926671633231")
addappid(3065804, 1, "a9fb32de62e3185f7da88c5cfeebfa8be3e95f12fe7947c202c6c72cffd9463a")  -- Depot 3065804
setManifestid(3065804, "5384055525140175288")
addappid(3065805, 1, "d9c1100fd72d15632afa42ca88ef15942940bf1d9fe988e7ccd4f89956d9f1bd")  -- Depot 3065805
setManifestid(3065805, "6798413815054975099")
addappid(3065806, 1, "cbbe4001937a5869feb979a0735838178e11f396145a8ba3b429605559571e11")  -- Depot 3065806
setManifestid(3065806, "1842476772863531743")
addappid(3065807, 1, "64134cffcc214f0050db0303a38ff31eb6f9b0bd8bfc6fe6c54d7491cd2bfedf")  -- Depot 3065807
setManifestid(3065807, "581092934313707647")
addappid(3065808, 1, "c0465c21465d02c42fefc99f192d3fc7706c0fb1d5137d43eda0a230d32bd81d")  -- Depot 3065808
setManifestid(3065808, "4176749539103506725")
addappid(3065809, 1, "c70d1f620b43534dba5c2f6fecba228b93987bbe9e13b73e5ce82dcd44e9dd83")  -- Depot 3065809
setManifestid(3065809, "1118728261617079316")
addappid(3551860, 1, "38ae85dcafe40d80464799e89aba553a4a38b5056beecd7c1baa4e572a87d8b1")  -- Depot 3551860
setManifestid(3551860, "6409813731161644720")
addappid(3551861, 1, "95915f90c16210b1e78922f01e3256ab2d8cc91ce74f77a2a60b49eb8600dbfc")  -- Depot 3551861
setManifestid(3551861, "4985956776007147203")
addappid(3551862, 1, "7be7f43cb3baac63b8b48b58634ea732cb0e4dda0f16bbe34d08e3c86d5817c4")  -- Depot 3551862
setManifestid(3551862, "4110728772883807589")
addappid(3551863, 1, "3add136df05da956359e78385400e4f12ceb9ef369a49143158612d4a0414217")  -- Depot 3551863
setManifestid(3551863, "99105723743314082")
addappid(3551864, 1, "7ebd0fd7666847e4a3b10ee9ef53948296bfccdd0edb1f0167265d85b5f1c7e3")  -- Depot 3551864
setManifestid(3551864, "5543324602787742492")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 13:33:16 GMT
-- Depots: 14 | Manifests: 14 | All included ✓
-- DLCs: 16
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


