-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 3164500
-- Name: Schedule I
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Schedule I
-- App ID: 3164500

addappid(3164500)  -- Schedule I
addappid(3164501,0,"81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4")  -- Depot 3164501
setManifestid(3164501, "3828069228120160165")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:23:14 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


