-- =====================================================
-- fetched from DepotBox Gen
-- =====================================================

-- AppID: 1529570
-- Name: MorphVOX Pro 5 - Voice Changer
-- made by DepotBox Gen

-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1529570.lua
addappid(1529570)
setManifestid(228990,"1829726630299308803")
setManifestid(229002,"7260605429366465749")
setManifestid(229006,"1784011429307107530")
addappid(1529571,0,"7644dd8db3fe3d54a8c304c530d7c0bbdd9437c01a87406bf156cd6f5cc95093")
setManifestid(1529571,"4666825533218592651")
addappid(1529576,0,"21ffaf16aeb8bfa25ea5b3560718cb8dd88d5eaad6e4c4c8515445e45ca2252e")
setManifestid(1529576,"5726947796747121369")
addappid(1535250)
addappid(1535251)
addappid(1535260)
addappid(1535261)
addappid(1535262)
addappid(1535263)
addappid(1535264)
addappid(1535265)
addappid(1535266)
addappid(1535400)
addappid(1535580)


