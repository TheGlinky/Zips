-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 991260
-- Name: Borderlands 2 VR
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Borderlands 2 VR
-- App ID: 991260

addappid(991260)  -- Borderlands 2 VR

addappid(991261, 1, "a3dfffbc00e24551b2cff222f4736d383a960a1957e5afd4e69b287cfc6b5400")  -- Depot 991261
setManifestid(991261, "2594482743839673571")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

addappid(991262, 1, "57ce37728eaf3997849c2ae529c6ead9c222df09124cc9b9329d024cee2f6261")  -- Depot 991262
setManifestid(991262, "2492999669730761521")

addappid(991263, 1, "11ec3c62a62929b4027a35b2c385326fa9d36916cf986980bfb21530c866aaef")  -- Depot 991263
setManifestid(991263, "3886563136252809433")

addappid(991264, 1, "1147224f62bac402a19d38b9d90523d13a0bd405840ab0e5b5c2002c1fdf765b")  -- Depot 991264
setManifestid(991264, "2104169220596163748")

addappid(991265, 1, "4c1d83a76df93ae73096c5dd162b43bccfce3005a3075bbf4c862c188904d362")  -- Depot 991265
setManifestid(991265, "343205011938971620")

addappid(991266, 1, "6b0ebca423aede7881a7ef794875a37b7c94337e00e9e7b86eb899127fd378d5")  -- Depot 991266
setManifestid(991266, "8718485485347051257")

addappid(991267, 1, "a0d234a92ff2917f195800c3ce65e8a34b87d1cd68ae58b3eee5a9c3796cc139")  -- Depot 991267
setManifestid(991267, "8803429855327714345")

addappid(991268, 1, "60cbceed6feb7311365f59d8da2a8f579126ce9725299188c2be1457089ccb25")  -- Depot 991268
setManifestid(991268, "4133101178963447382")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046900, 1, "55d0f7a80b7f1a01e0b40c604a4e5a810430edb01c3f12997fc50fe44769605f")  -- Depot 1046900
setManifestid(1046900, "1221998979517157683")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046901, 1, "2f5b88d9270432a6bfe8270e0337d0085df2084cc48f866d50a0f7a25618be0d")  -- Depot 1046901
setManifestid(1046901, "4847984316409922859")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046902, 1, "364759724e505695c0259a7147cfffc94dae610956e02e203e3b4497fb93cb0e")  -- Depot 1046902
setManifestid(1046902, "677235297889830388")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046903, 1, "2353c38580a8f1bcd47bed40743a8ef4201bdfe2a528cc8a9ec995d483f7cc57")  -- Depot 1046903
setManifestid(1046903, "891902819793351459")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046904, 1, "d06209eb4f51030bd357dd24e934f4c596694a680cd99c9492831fd098115bfd")  -- Depot 1046904
setManifestid(1046904, "4807309417527600954")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046905, 1, "3a23e71e3dc70ab78d8346b44912ad8a648cd3cfe8740be07a9715de2e1138d0")  -- Depot 1046905
setManifestid(1046905, "703040252076982561")

addappid(1046900)  -- Borderlands 2 VR BAMF DLC Pack (DLC)
addappid(1046906, 1, "0efa7c679205db259e9a7013aed1906659470bbee7870b9e0edc75ba1488cb7c")  -- Depot 1046906
setManifestid(1046906, "613706115367783983")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:19:51 GMT
-- Depots: 16 | Manifests: 16 | All included ✓
-- DLCs: 7
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


