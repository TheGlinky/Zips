-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1966720
-- Name: Lethal Company
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Lethal Company
-- App ID: 1966720

addappid(1966720)  -- Lethal Company
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")  -- Depot 228988
addappid(1966721,0,"b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949")  -- Depot 1966721
setManifestid(228988,"6645201662696499616")
setManifestid(1966721, "3474688902035454787")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:22:23 GMT
-- Depots: 2 | Manifests: 2 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


