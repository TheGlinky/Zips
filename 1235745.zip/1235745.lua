-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: The Sims™ 4 Parenthood
-- App ID: 1235745

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1235745, 1, "b1e6d2e9faab7a55e326962f56d84c1602536645064ed5d7e1afb4600c150c2e")  -- Depot 1235745
setManifestid(1235745, "6946578202027560398")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242360, 1, "0e81c1891faa56030af5e8da531ee6318e6a843e2bd15e06ee182df75a4cb125")  -- Depot 1242360
setManifestid(1242360, "3958365363340106518")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242361, 1, "6000878a4fd90b184b92ad4b931b40b97d58f313a329ba5dc727c62750e1e375")  -- Depot 1242361
setManifestid(1242361, "5546393268612584578")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242362, 1, "dad7f54c4d9dc12632c7a1e6ad041f1a362bf5b707cc1cb3c8890b8bd6bcb8b9")  -- Depot 1242362
setManifestid(1242362, "9059826949998769029")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242363, 1, "cac85be23bb1feab89447cc40a5daad7ecaf19eb0df9f61d5c66cb2a85f1d6cd")  -- Depot 1242363
setManifestid(1242363, "6780914613713903256")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242364, 1, "6357c0191fb589f767715b73726ddbca75b09499ca0fd8dd79875018f437be4f")  -- Depot 1242364
setManifestid(1242364, "6410301695928478805")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242365, 1, "421df882511fad9bd60c2eb7b6615e39299497de9b659c2af7d33ec3aec6f908")  -- Depot 1242365
setManifestid(1242365, "7454767384041184720")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242366, 1, "9febe0625c2c0f615aad39c09a47365e9c2a8890f58f2fdd5cfaba885ac1588e")  -- Depot 1242366
setManifestid(1242366, "4601687221564513801")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242367, 1, "9f6dc5699ed09f8401a35a741305e3f5b6b79d1fa0890f472d771c49b9ffbfaf")  -- Depot 1242367
setManifestid(1242367, "6673625822144225490")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242368, 1, "f9b8b7d10b2b323c6ed672ad75d82652cf7f0246a703d2b0e4a315dc9ca47a69")  -- Depot 1242368
setManifestid(1242368, "8420978423919238950")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242369, 1, "0d2e5b8e485d3e24fbf234004027cc24f456025e5b141bea7abd70014a13d079")  -- Depot 1242369
setManifestid(1242369, "7411484375839379972")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242370, 1, "d26eabaf8a040ca96608ae8e3f4f1b5280214d166e2a4152afaa91980bac658f")  -- Depot 1242370
setManifestid(1242370, "3451765925247527553")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242371, 1, "2e81b849f44eb227af77fa92cfd525f1380671f159793441ae4cc07d16075f36")  -- Depot 1242371
setManifestid(1242371, "3942542378379877409")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242372, 1, "dec20d90e612dcdcd5f73216eda47e1312b168d12ed6b6178fe93305d263057f")  -- Depot 1242372
setManifestid(1242372, "9097629904321249013")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242373, 1, "3f5cf66fd10a8b18af8e3ef50c215846933e4ba9bd77cb5b479a6a5c6d2553a3")  -- Depot 1242373
setManifestid(1242373, "2094060257375822380")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242374, 1, "c77fafcd1cb71da645a043f74db9ffbd4567b2a4f03adddb6622c9345502481b")  -- Depot 1242374
setManifestid(1242374, "3463599991551445979")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242375, 1, "3ed1107995cf431a0e0af472044d54c32e2f8165c9330c7ad2b2585445c9945a")  -- Depot 1242375
setManifestid(1242375, "3912332427596454552")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242376, 1, "d9157fa3ae556e7c5a91859dad4b11d451b34c3d2a367bc0850d8865de8d2de8")  -- Depot 1242376
setManifestid(1242376, "6271482784408278346")

addappid(1235745)  -- The Sims™ 4 Parenthood (DLC)
addappid(1242377, 1, "dd7a0e826091c9a387b3cd19bcc9e86e744b87488e86cb9d1d116208e8e620df")  -- Depot 1242377
setManifestid(1242377, "8631708220960636964")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:19:58 GMT
-- Depots: 19 | Manifests: 19 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════
