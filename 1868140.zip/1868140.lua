-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1868140
-- Name: DAVE THE DIVER
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: App 1868140
-- App ID: 1868140

addappid(1868140)  -- App 1868140

addappid(1868141, 1, "dec1482ee88e2a62d7fddedf0e75c6abdef55d2884440de6508bef83044198d8")  -- Depot 1868141
setManifestid(1868141, "4667272369299107337")

addappid(1868142, 1, "f55cec1c353af17ba294e0bc3c1af6766a91b76e97d59d44425873918058d6c5")  -- Depot 1868142
setManifestid(1868142, "2867823458894057217")

addappid(2492320)  -- App 2492320
addappid(2492320, 1, "80467121a86d6b38971889737a91b309bb3aa329fee8e93ac63f2748f43fa063")  -- Depot 2492320
setManifestid(2492320, "8303250180391868718")

addappid(2677020)  -- App 2677020
addappid(2677020, 1, "0f12757b1a8cc78265828ba98e12b673ff97e942bbfd3ae07eca6d10f6b8dfcf")  -- Depot 2677020
setManifestid(2677020, "3523098559722946035")

addappid(2677020)  -- App 2677020
addappid(2677021, 1, "794d4476c6913ad8568af8bf1303f216b1f16b3d6041f62834536fe460d661dd")  -- Depot 2677021
setManifestid(2677021, "2579806968208051974")

addappid(2841140)  -- App 2841140
addappid(2841140, 1, "a5e4472216eb53c5abc48c617b42bc740a1fac4adf25659c183015a27f8849fb")  -- Depot 2841140
setManifestid(2841140, "5969075150231517220")

addappid(2841140)  -- App 2841140
addappid(2841141, 1, "a6863e71aca974796ecc6423cb6d8b9820fd11e9df7f06bcbaa7a1926227f77d")  -- Depot 2841141
setManifestid(2841141, "1811376077504623732")

addappid(3543180)  -- App 3543180
addappid(3543180, 1, "5dbf7b425cf6ac47d95a2abe30926e2c845f6b9fbf05903c27837624a56b6b66")  -- Depot 3543180
setManifestid(3543180, "8491586211128714786")

addappid(3543180)  -- App 3543180
addappid(3543181, 1, "fda6ac6e3da3645d6c445ad4c68bffd11640df814da698f3fb85db7ada2a388b")  -- Depot 3543181
setManifestid(3543181, "1623285286579638098")

setManifestid(4158580, "4147139220239033605")

setManifestid(4158581, "6576173497187422279")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 15:01:56 GMT
-- Depots: 9 | Manifests: 11 | All included ✓
-- DLCs: 7
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


