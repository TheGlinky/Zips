-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 976310
-- Name: Mortal Kombat 11
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Mortal Kombat 11
-- App ID: 976310

addappid(1471870)  -- Mortal Kombat 11 Ultimate Add-On Bundle (DLC)
addappid(1449880)  -- Mortal Kombat 11 Kombat Pack 2 (DLC)
addappid(1054480)  -- Mortal Kombat 11 Kombat Pack 1 (DLC)
addappid(1273971)  -- Mortal Kombat 11: Aftermath Expansion (DLC)
addappid(1480230)  -- Mortal Kombat 11 Klassic MK Movie Skin Pack (DLC)
addappid(1449881)  -- Mortal Kombat 11 Rain (DLC)
addappid(1449882)  -- Mortal Kombat 11 Mileena (DLC)
addappid(1449883)  -- Mortal Kombat 11 Rambo (DLC)
addappid(1461160)  -- Mortal Kombat 11 4K Cinematic Pack (DLC)
addappid(1160240)  -- Mortal Kombat 11 Terminator T-800 (DLC)
addappid(1160241)  -- Mortal Kombat 11 Double Feature Skin Pack (DLC)
addappid(1051620)  -- Mortal Kombat 11 Shao Kahn (DLC)
addappid(1051621)  -- Mortal Kombat 11 Frost (DLC)
addappid(1095030)  -- Mortal Kombat 11 Shang Tsung (DLC)
addappid(1095031)  -- Mortal Kombat 11 Klassic Arcade Ninja Skin Pack 1 (DLC)
addappid(1116620)  -- Mortal Kombat 11 Nightwolf (DLC)
addappid(1116621)  -- Mortal Kombat 11 Klassic Arcade Fighter Pack (DLC)
addappid(1160243)  -- Mortal Kombat 11 Masquerade Skin Pack (DLC)
addappid(1180720)  -- Mortal Kombat 11 Sindel (DLC)
addappid(1180721)  -- Mortal Kombat 11 Gothic Horror Skin Pack (DLC)
addappid(1200550)  -- Mortal Kombat 11 The Joker (DLC)
addappid(1200552)  -- Mortal Kombat 11 DC Elseworlds Skin Pack (DLC)
addappid(1253300)  -- Mortal Kombat 11 Spawn (DLC)
addappid(1253302)  -- Mortal Kombat 11 Matinee Skin Pack (DLC)
addappid(1316180)  -- Mortal Kombat 11 Fujin (DLC)
addappid(1316181)  -- Mortal Kombat 11 Sheeva (DLC)
addappid(1316182)  -- Mortal Kombat 11 Robocop (DLC)

addappid(976310)  -- Mortal Kombat 11
addappid(228986,0,"51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")  -- Depot 228986
addappid(976311,0,"ba51ae236d415e34a5aa7366e15b74cd96587031f70d2acaf46ac5b390b0f4d9")  -- Depot 976311
addappid(976312,0,"37130205b90f533304b81a7d155c3f74576759eaab5e9f7d4e92478404205f60")  -- Depot 976312
addappid(976313,0,"b8e08c7b5961c5daa928f561f46d5c8438ca9c016ed0c5e9bbe5827d0b7dfdb7")  -- Depot 976313
setManifestid(228986,"8782296191957114623")
setManifestid(976311,"6512752024476768865")
setManifestid(976312,"1715536566262804393")
setManifestid(976313,"4245947103270175452")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:17:51 GMT
-- Depots: 4 | Manifests: 4 | All included ✓
-- DLCs: 27
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


