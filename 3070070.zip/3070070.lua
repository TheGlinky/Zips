-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 3070070
-- Name: TCG Card Shop Simulator
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: TCG Card Shop Simulator
-- App ID: 3070070

addappid(3070070)  -- TCG Card Shop Simulator
addappid(3070071,0,"5c49dfd1ba36d4e81f59ad3a2cd714ec14bdb40ac41848727aca2dc9ed29c748")  -- Depot 3070071
setManifestid(3070071, "5587582569479621934")
-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:26:59 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


