-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 469610
-- Name: Rick and Morty: Virtual Rick-ality
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Rick and Morty: Virtual Rick-ality
-- App ID: 469610

addappid(469610)  -- Rick and Morty: Virtual Rick-ality

addappid(469611, 1, "7abcef197bdb04642c4e4e7384e694c1d8e5d847888d64fdca45c9d415ebd928")  -- Depot 469611
setManifestid(469611, "7496817212561796262")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:24:10 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


