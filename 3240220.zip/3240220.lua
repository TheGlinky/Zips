-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 3240220
-- Name: Grand Theft Auto V Enhanced
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Grand Theft Auto V Enhanced
-- App ID: 3240220

addappid(3240220)  -- Grand Theft Auto V Enhanced
addappid(3240221,0,"61fc2e176574df29022e435d489e10efa92e38b3297e1f0c641e63b11df58a8a")  -- Depot 3240221
addappid(3240222,0,"a90ba98205062c9ae855344794a6a3e0e9e59d825595f0508d7276e4d26da852")  -- Depot 3240222
addappid(3240223,0,"46bece69b70a0f45bc94213cabf17a5a8e0546fe5b42c9d71f357f9fd7eaa605")  -- Depot 3240223
addappid(3240224,0,"3ff530fbca5308cf7d55f33334770b536834d48139880615673f26e3569b99d9")  -- Depot 3240224
addappid(3240225,0,"8951f7eb7724cc2b407c9170e8bf5ce6792f8d6a7ad6a42c460a74abacac719a")  -- Depot 3240225
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")  -- Depot 1899671
setManifestid(1899671, "274155245002712969")
setManifestid(3240221, "7738940149188702855")
setManifestid(3240222,"8737726049140786475")
setManifestid(3240223,"6109028520665039655")
setManifestid(3240224,"3207789125684884376")
setManifestid(3240225, "7524661139560880719")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:26:40 GMT
-- Depots: 6 | Manifests: 6 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


